<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>ex 1</h1>
<form method="POST" action="pagina2.php">
    <label for="name">nome</label>
        <input type="text" name="nome">
   
     
</br>   <label for="idade">idade</label>
        <input type="text" name="idade">
    
        <input type="submit" value="Próximo">
    </form>
    <hr/>
    <h1>EX 2</h1>
    <form method="POST" action="pagina3.php">
    <label for="numero">numero</label>
   <input type="text" name="numero">    
<input type="submit" value="Próximo">
    </form>
</body>
</html> 

<?php 

 ?>
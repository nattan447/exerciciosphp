<?php 
$numero=$_POST['numero'];
$objetos = [
    ["mes" => 1,"texto"=>"janeiro"],
    ["mes" => 2,"texto"=>"fevereiro"],
    ["mes" => 3,"texto"=>"março"],
    ["mes" => 4,"texto"=>"abril"],
    ["mes" => 5,"texto"=>"maio"],
    ["mes" => 6,"texto"=>"junho"],
    ["mes" => 7,"texto"=>"julho"],
    ["mes" => 8,"texto"=>"agosto"],
    ["mes" => 9,"texto"=>"setembro"],
    ["mes" => 10,"texto"=>"outubro"],
    ["mes" => 11,"texto"=>"novembro"],
    ["mes" => 12,"texto"=>"dezembro"],

];

for($i=0;$i<sizeof($objetos);$i++){
    echo($objetos[$i]["texto"]);
};
?>